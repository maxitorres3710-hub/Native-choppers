# Native Helicopters: investigación de adaptación Android

**Estado: prototipo de diagnóstico corregido y preparado para compilación automatizada; todavía no es un mod jugable.**

Objetivo: GTA III Android 1.8 ARMv7, usando la biblioteca `libR1.so` del APK proporcionado.

Incluye:
- `original_pc_cleo/`: los dos scripts originales de PC sin modificar.
- `aml_armv7_probe/`: fuente C++ de un hook de diagnóstico AML; no cambia el comportamiento del juego.
- `docs/`: símbolos y resultados del análisis estático.

La investigación confirma símbolos nativos de `CHeli`, pero no demuestra que se pueda crear un helicóptero pilotable con una llamada sencilla. `CHeli` y `CAutomobile` son clases diferentes, por lo que cambiar punteros, vtables o estructuras a ciegas puede provocar cierres o corrupción de memoria.

Los `.cs` originales dependen de `III.NativeHelicopters.asi`, un plugin Windows/x86. Renombrarlos a `.csa` no los convierte para Android. No se incluyen funciones de armamento.

## Para la siguiente fase

Hace falta el SDK/cabeceras de Android Mod Loader (AML) compatible con el juego y confirmar que AML ya está instalado y cargando mods en el teléfono. Esta sesión no dispone del Android NDK ni de las cabeceras oficiales AML locales. Se añadió un workflow de GitHub Actions que puede descargar las herramientas y compilar el prototipo en la nube; el artefacto debe generarse ejecutando ese workflow. La compilación no habilita pilotaje ni crea helicópteros aparcados.
