# Empezar desde un teléfono Android

Este proyecto incluye un workflow de GitHub Actions para que la compilación use una máquina Linux en la nube. No necesitas instalar el NDK ni compilar en tu teléfono.

1. Crea un repositorio vacío en GitHub desde el navegador del teléfono.
2. Sube **el contenido de esta carpeta** a la raíz del repositorio. Es importante que `.github/workflows/build-android.yml` quede en la raíz del repo, no dentro de una carpeta anidada.
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build Native Helicopters Android probe** y pulsa **Run workflow**.
5. Cuando termine en verde, abre la ejecución y descarga el artefacto `NativeHelicoptersAndroidProbe-ARMv7`.

El workflow obtiene Android NDK y las cabeceras AML oficiales, y luego intenta compilar el módulo. No he podido ejecutar ese workflow desde esta sesión porque no tengo acceso de escritura a un repositorio GitHub del usuario ni hay Android NDK instalado aquí.

**Importante:** el resultado es solo un módulo de diagnóstico de hook. No habilita pilotaje, helicópteros aparcados ni rotores modificados. No lo instales en el juego hasta que la compilación termine correctamente y el registro confirme que el hook se instaló y fue ejecutado.
