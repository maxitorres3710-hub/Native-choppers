# GTA III Native Helicopters: análisis de port a Android

## Resultado

El ZIP recibido **no incluye el código fuente del plugin**. Contiene un plugin de Windows ya compilado y dos scripts CLEO de PC compilados. No existe una conversión directa de ese `.asi` a `.so` o `.csa` que conserve su comportamiento.

## Inventario

- `III.NativeHelicopters.asi`: biblioteca PE32 / x86 para Windows (DLL), no una biblioteca ELF de Android. Importa funciones de `KERNEL32.dll`; aparecen símbolos de C++ como `NativeChopper`, `toprotor`, `backrotor` y referencias a Plugin-SDK.
- `CLEO/[=SF=]HeliParkGenerator.cs`: script CLEO compilado con identificador `HELIGEN`.
- `CLEO/[=SF=]HeliProperties.cs`: script CLEO compilado con identificador `HELIPRP`.

Los archivos `.cs` son datos binarios de scripts, no fuentes C#. El script `HELIPRP` referencia explícitamente `III.NATIVEHELICOPTERS.ASI`, realiza llamadas a direcciones absolutas de la versión de PC (entre ellas `0x551170`, `0x547540` y `0x5477F0`) y accede a un campo por desplazamiento `0x284`. Por tanto, aunque se cambie la extensión a `.csa`, el script no se vuelve compatible con la memoria y las funciones de GTA III Android.

## Port que tiene sentido desarrollar

1. **Reescritura CLEO Android:** reconstruir la lógica de creación/aparición de helicópteros y las interacciones que puedan resolverse con opcodes disponibles en la versión móvil. No copiar a ciegas los opcodes, controles o punteros de PC.
2. **Plugin nativo Android:** rehacer los ganchos que convierten los modelos `CHOPPER` y `ESCAPE` en vehículos pilotables, gestionan el comportamiento de vuelo y la animación de rotores. Se requiere compilar una biblioteca Android (`.so`) para la ABI exacta y usar un cargador compatible.
3. **Prueba por versión:** validar contra la biblioteca nativa de la APK objetivo; las direcciones y estructuras deben descubrirse para esa compilación específica. No reutilizar offsets de GTA III PC.
4. **Alcance de la primera versión:** pilotaje, entrar/salir, rotores y helicópteros aparcados. Se dejan fuera las funciones de armamento del mod original.

## Qué falta para continuar hasta un binario instalable

- La biblioteca nativa (`.so`) extraída de **la misma APK de GTA III Android que se está usando**, y el número/edición de esa versión.
- La ABI que trae la APK (`armeabi-v7a`, `arm64-v8a` u otra) y el cargador de mods disponible en esa instalación (por ejemplo CLEO Android o AML).
- Para reproducir fielmente el plugin original, sería ideal obtener el código fuente original. Sin él, el comportamiento nativo debe reconstruirse mediante análisis del binario y pruebas.

## Estado honesto

Este archivo documenta el análisis estático y la ruta técnica. **Todavía no es un mod funcional ni se ha generado un `.so` probado en Android**: con solo el binario de PC y los scripts dependientes no hay información suficiente para crear responsablemente un plugin que enganche la versión móvil correcta.

## Referencias técnicas

- CLEO Android: https://github.com/cleolibrary/CLEO-ANDROID
- PoC de cargador ASI para Android (ilustra que los plugins deben ser bibliotecas compatibles con Android, no PE de Windows): https://github.com/spmn/GTA.Android.ASILoader
