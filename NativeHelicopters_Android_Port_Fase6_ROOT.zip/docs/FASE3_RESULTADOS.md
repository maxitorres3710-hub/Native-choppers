# Fase 3: comprobación de clases nativas

## Confirmado en el APK aportado

La biblioteca examinada es `lib/armeabi-v7a/libR1.so` (ELF32 ARM de 32 bits). La tabla dinámica/exportada contiene estos símbolos relevantes para el helicóptero: `CHeli::CHeli(int, unsigned char)`, `CHeli::ProcessControl()`, `CHeli::PreRender()`, `CHeli::Render()`, `CHeli::InitHelis()`, `CHeli::UpdateHelis()` y `CHeli::ActivateHeli(bool)`. También se encontraron constructores de `CVehicle` y `CAutomobile`, además de sus tablas virtuales.

## Qué significa

- El APK tiene una implementación nativa de helicópteros y símbolos que una extensión AML podría resolver por nombre.
- La existencia de `CHeli` no prueba que los helicópteros se puedan conducir como vehículos normales.
- Los constructores y las tablas virtuales indican que `CHeli`, `CVehicle` y `CAutomobile` son clases distintas; forzar una conversión entre clases sin conocer los tamaños, campos y funciones virtuales puede corromper memoria.
- No se ha confirmado una función pública segura para crear helicópteros aparcados arbitrarios. `CHeli::InitHelis()` y `CHeli::UpdateHelis()` son rutinas internas del sistema de helicópteros, no una API de creación general.

## Resultado de esta fase

Esta fase confirma los puntos de entrada candidatos, pero no modifica el juego. No hay un binario de mod jugable. No se generó una conversión ficticia de los `.cs` a `.csa`: los scripts de PC dependen del plugin Windows `III.NativeHelicopters.asi`, y ese plugin no se puede cargar en Android.

## Próximo bloqueo técnico

Para seguir hacia una implementación que pueda probarse hacen falta las cabeceras/SDK de Android Mod Loader (AML) compatibles con la versión instalada y confirmar que AML carga mods en el dispositivo. Sin esas cabeceras no se puede compilar ni verificar el hook; sin pruebas en el dispositivo no se debe habilitar ningún parche de memoria.

## Alcance

El trabajo se limita a helicópteros aparcados, acceso/uso del vehículo y animación de rotores. Se excluyen las funciones de armamento.
