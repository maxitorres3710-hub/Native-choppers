# Análisis estático de GTA III Android

## Biblioteca principal

`lib/armeabi-v7a/libR1.so` es una biblioteca ELF32 para ARM de 32 bits. Los símbolos de `CHeli` siguen exportados, lo cual permite intentar resolverlos por nombre en vez de copiar direcciones absolutas del GTA III de PC.

## Símbolos útiles localizados

- `CHeli::ProcessControl()` — símbolo `_ZN5CHeli14ProcessControlEv`
- `CHeli::UpdateHelis()` — símbolo `_ZN5CHeli11UpdateHelisEv`
- `CHeli::InitHelis()` — símbolo `_ZN5CHeli9InitHelisEv`
- `CHeli::Render()` — símbolo `_ZN5CHeli6RenderEv`
- `CHeli::PreRender()` — símbolo `_ZN5CHeli9PreRenderEv`
- `CHeli::ActivateHeli(bool)` — símbolo `_ZN5CHeli12ActivateHeliEb`
- `CHeli::SpawnFlyingComponent(int)` — símbolo `_ZN5CHeli19SpawnFlyingComponentEi`
- `CHeli::SpecialHeliPreRender()` — símbolo `_ZN5CHeli20SpecialHeliPreRenderEv`

Los nombres por sí solos no revelan el comportamiento completo ni demuestran que una rutina pueda llamarse desde cualquier punto. En particular, no deben llamarse funciones internas a ciegas.

## Diferencia con el mod de PC

El archivo `III.NativeHelicopters.asi` es PE32 para Windows/x86. No puede cargarse como biblioteca Android. Los archivos `.cs` incluidos son scripts CLEO compilados para PC, con cabeceras y opcodes de PC; renombrarlos a `.csa` no los adapta.

## Límite de esta entrega

Se identificaron símbolos y se preparó un prototipo de hook por nombre. No se ha compilado contra el SDK AML ni probado en un dispositivo real. Por tanto, no se afirma que el hook ya funcione ni que los helicópteros sean pilotables.

## Análisis del ASI original de PC

El `III.NativeHelicopters.asi` aportado es PE32/i386 para Windows, con importaciones de `KERNEL32.dll` como `VirtualProtect`, `GetModuleHandleA` y `GetProcAddress`. Sus cadenas incluyen `toprotor`, `backrotor` y clases del framework de hooks de `injector`. Esto confirma que el mod depende de hooks nativos específicos de Windows/x86; no existe una conversión binaria directa a ARM Android.

Los scripts `HeliParkGenerator.cs` y `HeliProperties.cs` comienzan con cabeceras binarias (`HELIGEN` y `HELIPRP`) y no son fuentes de texto editables. El primero parece dedicado a generar helicópteros aparcados; el segundo, a propiedades del helicóptero. Sus opcodes y direcciones de PC no deben ejecutarse directamente en Android.
