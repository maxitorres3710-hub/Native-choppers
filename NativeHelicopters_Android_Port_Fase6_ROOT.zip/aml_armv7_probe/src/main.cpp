/*
 * Native Helicopters Android - AML hook-validation probe
 * Target: GTA III Android 1.8, armeabi-v7a, libR1.so.
 *
 * Diagnostic only: preserves CHeli::ProcessControl and logs when reached.
 * It does not change vehicle physics, spawn helicopters, modify rotors, or
 * add weapon behavior. This is NOT yet the gameplay port.
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <cstdint>

MYMOD(net.max.nativeheliandroid, Native Helicopters Android Probe, 0.2.0, Max)

static bool gLoggedFirstHeliTick = false;
static bool gHookInstalled = false;

DECL_HOOKv(HeliProcessControl, void* self)
{
    HeliProcessControl(self); // Preserve original game behavior.
    if (!gLoggedFirstHeliTick)
    {
        gLoggedFirstHeliTick = true;
        logger->Info("CHeli::ProcessControl hook reached; original function preserved.");
    }
}

ON_MOD_PRELOAD()
{
    logger->SetTag("NativeHeliAndroid");
    logger->Info("Diagnostic probe starting; no gameplay changes enabled.");
}

ON_MOD_LOAD()
{
    const char* symbol = "_ZN5CHeli14ProcessControlEv";
    void* handle = aml->GetLibHandle("libR1.so");
    if (!handle)
    {
        logger->Error("libR1.so handle unavailable; hook not installed.");
        return;
    }

    const uintptr_t target = aml->GetSym(handle, symbol);
    if (!target)
    {
        logger->Error("CHeli::ProcessControl symbol not found; hook not installed.");
        return;
    }

    // Use AML's documented low-level API so installation success is checked.
    gHookInstalled = aml->Hook(
        reinterpret_cast<void*>(target),
        reinterpret_cast<void*>(HookOf_HeliProcessControl),
        reinterpret_cast<void**>(&HeliProcessControl));

    if (gHookInstalled)
        logger->Info("Hook installed at %p; waiting to verify execution.", reinterpret_cast<void*>(target));
    else
        logger->Error("AML rejected the hook; game behavior left unchanged.");
}

ON_MOD_UNLOAD()
{
    // AML does not guarantee unload callbacks during process shutdown.
    logger->Info("Probe unload callback reached. Hook installed=%d", gHookInstalled ? 1 : 0);
}
