# Native Helicopters Android Probe (ARMv7)

This is a diagnostic-only AML module. If compiled successfully and loaded by AML, it attempts to hook the existing `CHeli::ProcessControl()` symbol and logs whether AML accepted the hook and whether the hook was reached.

It does **not** enable helicopter entry/pilotage, spawn parked helicopters, change rotor animation, or alter weapons.

## Cloud build

The repository includes `.github/workflows/build-android.yml`. Upload the project to a GitHub repository, open **Actions**, select **Build Native Helicopters Android probe**, and choose **Run workflow**. A successful run uploads a `NativeHelicoptersAndroidProbe-ARMv7` artifact containing the `.so` and this note.

This build has not been executed by the authoring environment. The artifact is not present until the workflow actually runs successfully. Do not install a `.so` from a failed or incomplete build.
